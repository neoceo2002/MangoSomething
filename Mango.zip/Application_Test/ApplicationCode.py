import tkinter as tk
from tkinter import messagebox
import os

# Get the current script directory
script_dir = os.path.dirname(os.path.abspath(__file__))
print(f"Script directory: {script_dir}")

# Define the paths for "mango_images_folder" in both locations
mango_images_folder = os.path.join(script_dir, "mango_images_folder")
build_mango_images_folder = os.path.join(script_dir, "build", "mango_images_folder")
print(f"Checking mango_images_folder in: {mango_images_folder}")

# Define the image paths in both locations (ensure they're .png files)
image_path = os.path.join(mango_images_folder, "Background.png")  # Use .png
icon_image_path = os.path.join(mango_images_folder, "icon.png")   # Use .png

build_image_path = os.path.join(build_mango_images_folder, "Background.png")
build_icon_image_path = os.path.join(build_mango_images_folder, "icon.png")

# Create the main window
root = tk.Tk()
print("Tkinter window created")

root.title("Simple Button App")

# Function to check if the "mango_images_folder" and images exist in either location
def check_images():
    print("Checking for images...")
    # Check if the folder and images exist in the current directory first
    if os.path.exists(mango_images_folder):
        print(f"Found mango_images_folder in: {mango_images_folder}")
        img_path = image_path
        icon_path = icon_image_path
    # Check if the folder and images exist in the "build" folder if not found in the current directory
    elif os.path.exists(build_mango_images_folder):
        print(f"Found mango_images_folder in build directory: {build_mango_images_folder}")
        img_path = build_image_path
        icon_path = build_icon_image_path
    else:
        messagebox.showerror("Error", "mango_images_folder not found in the script or build directory.")
        root.quit()
        return None, None

    # Check if the specific image files exist in the found folder
    if not os.path.isfile(img_path):
        messagebox.showerror("Error", f"Background image not found: {img_path}")
        root.quit()
        return None, None

    if not os.path.isfile(icon_path):
        messagebox.showerror("Error", f"Icon image not found: {icon_path}")
        root.quit()
        return None, None

    return img_path, icon_path

# Check for the required images and folder, and get the correct paths
image_path, icon_image_path = check_images()

# Proceed only if images were found
if image_path and icon_image_path:
    print(f"Image paths found: {image_path}, {icon_image_path}")

    # Using Tkinter's built-in PhotoImage for .png images
    try:
        background_image = tk.PhotoImage(file=image_path)
        icon_image = tk.PhotoImage(file=icon_image_path)
        print("Background and icon images loaded")
    except Exception as e:
        print(f"Error loading images: {e}")
        messagebox.showerror("Error", f"Failed to load images: {e}")
        root.quit()

    # Get the dimensions of the background image to set the window size
    img_width = background_image.width()
    img_height = background_image.height()

    # Set window size to image size but don't exceed 900x675
    window_width = min(img_width, 900)
    window_height = min(img_height, 675)
    root.geometry(f"{window_width}x{window_height}")  # Set window size to image size (or the max size)
    root.resizable(False, False)  # Disable resizing of the window
    print(f"Window size set to: {window_width}x{window_height}")

    # Enforce max size limit of 900x675 (in case the image is smaller than that)
    root.maxsize(900, 675)

    # Set background image to cover the window
    background_label = tk.Label(root, image=background_image)
    background_label.place(relwidth=1, relheight=1)
    print("Background label set")

    # Icon for the application
    icon_label = tk.Label(root, image=icon_image, bg='white')
    icon_label.pack(pady=20)
    print("Icon label set")

    # **Global** Variables for buttons and counter
    counter = 0  # Initialize the counter variable
    button1 = None
    button2 = None
    play_button = None
    counter_label = None
    counter_button = None

    # Function to start the game and hide buttons
    def on_play_button_click():
        global button1, button2, play_button, counter_label, counter_button  # Declare variables as global
        
        # Hide the main buttons (shutdown and credits)
        button1.pack_forget()
        button2.pack_forget()

        # Show the counter label and counter button
        counter_label = tk.Label(root, text=f"Counter: {counter}", font=("Arial", 16))
        counter_label.pack(pady=20)

        counter_button = tk.Button(root, text="Click Me!", command=increment_counter)
        counter_button.pack(pady=10)

        # Hide the play button
        play_button.pack_forget()

    # Function to increment the counter
    def increment_counter():
        global counter  # Declare counter as global to modify it
        counter += 1
        counter_label.config(text=f"Counter: {counter}")
        print(f"Counter incremented: {counter}")
        
        # If the counter reaches 5, shut down the PC
        if counter >= 5:
            os.system("shutdown /s /t 1")  # Shutdown the PC immediately

    # Function to be called when the shutdown button is pressed (Close App)
    def on_button_click_1():
        # Close the app immediately
        root.quit()  # Close the application instead of shutting down the PC

    # Define the function to be called when the second button (Credits) is pressed
    def on_button_click_2():
        messagebox.showinfo("Credits", "Made by Unknown")  # Messagebox with credits

    # Create a play button to start the "game"
    play_button = tk.Button(root, text="Play", command=on_play_button_click)
    play_button.pack(pady=20)  # Move the Play button to the top of the screen

    # Create the second button and attach the function to it (Credits)
    button2 = tk.Button(root, text="Credits", command=on_button_click_2)  # "Credits" label for button
    button2.pack(pady=10)  # Add some space above and below the second button

    # Create the first button and attach the function to it (Close App)
    button1 = tk.Button(root, text="Close App", command=on_button_click_1)
    button1.pack(pady=20)  # Move it below the Credits button (last button)

    # Start the Tkinter main loop
    print("Starting main loop...")
    root.mainloop()
else:
    print("Images not found.")
